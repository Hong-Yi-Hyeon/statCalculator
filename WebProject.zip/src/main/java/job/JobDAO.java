package job;

import java.sql.SQLException;

import db.JDBConnect;

public class JobDAO extends JDBConnect {
	public JobDAO(String driver, String url, String id, String pw) {
		super(driver, url, id, pw);
	}
	
	public JobDTO getJobDTO(String job) {
		JobDTO dto = new JobDTO();
		String sql = "SELECT * FROM calculator WHERE job=?";
		
		try {
			psmt = con.prepareStatement(sql);
			psmt.setString(1, job);
			rs = psmt.executeQuery();
			
			if(rs.next()) {
				dto.setJob(job);
				dto.setWeaponConstant(rs.getString("weaponConstant"));
				dto.setJobConstant(rs.getString("jobConstant"));
				dto.setFinalDamage(rs.getString("finalDamage"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return dto;
	}
}
