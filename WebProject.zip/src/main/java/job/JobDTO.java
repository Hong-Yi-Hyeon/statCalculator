package job;

public class JobDTO {
	private String job;
	private String weaponConstant;
	private String jobConstant;
	private String finalDamage;
	
	public JobDTO() {}

	public String getJob() { return job; }
	public void setJob(String job) { this.job = job; }
	public double getWeaponConstant() { return Double.parseDouble(weaponConstant); }
	public void setWeaponConstant(String weaponConstant) { this.weaponConstant = weaponConstant; }
	public double getJobConstant() { return Double.parseDouble(jobConstant); }
	public void setJobConstant(String jobConstant) { this.jobConstant = jobConstant; }
	public double getFinalDamage() { return Double.parseDouble(finalDamage); }
	public void setFinalDamage(String finalDamage) { this.finalDamage = finalDamage; }
}
